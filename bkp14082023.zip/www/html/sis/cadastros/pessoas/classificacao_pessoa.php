<?php
include ("../../includes/config.php"); 
include ("../../includes/conecta_bd.php");
include ("../../includes/valida_cookies.php");
$pagina = "classificacao_pessoa";
$titulo = "Classifica&ccedil;&atilde;o Cadastro de Pessoa";	
$modulo = "cadastros";
$menu = "cadastro_pessoas";
// ================================================================================================================


// ====== RECEBE POST ==============================================================================================
$botao = $_POST["botao"];
$codigo_w = $_POST["codigo_w"];
$bloqueio_w = $_POST["bloqueio_w"];
$nome_form = $_POST["nome_form"];
$tipo_form = $_POST["tipo_form"];

$usuario_cadastro = $nome_usuario_print;
$data_cadastro = date('Y-m-d', time());
$hora_cadastro = date('G:i:s', time());
// =================================================================================================================


// ====== CRIA MENSAGEM =============================================================================================
if ($botao == "CADASTRAR" and $nome_form == "")
{$erro = 1;
$msg = "<div style='color:#FF0000'>Digite o nome da Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o</div>";}

elseif ($botao == "CADASTRAR" and $tipo_form == "")
{$erro = 2;
$msg = "<div style='color:#FF0000'>Selecione o tipo (Classifica&ccedil;&atilde;o ou Fun&ccedil;&atilde;o)</div>";}

elseif ($botao == "EDITAR" and $nome_form == "")
{$erro = 3;
$msg = "<div style='color:#FF0000'>Digite o nome da Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o</div>";
$nome_form = "";
$tipo_form = "";
$codigo_w = "";
$bloqueio_w = "";
}

elseif ($botao == "EDITAR" and $tipo_form == "")
{$erro = 4;
$msg = "<div style='color:#FF0000'>Selecione o tipo (Classifica&ccedil;&atilde;o ou Fun&ccedil;&atilde;o)</div>";
$nome_form = "";
$tipo_form = "";
$codigo_w = "";
$bloqueio_w = "";
}

elseif ($botao == "EXCLUSAO")
{$erro = 5;
$msg = "<div style='color:#FF0000'>Deseja realmente excluir esta Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o?</div>";
}

else
{$erro = 0;
$msg = "";}
// ==================================================================================================================


// ====== CADASTRAR NOVA CLASSIFICAÇÃO ====================================================================================
if ($botao == "CADASTRAR" and $erro == 0 and $permissao[73] == "S")
{
// CADASTRO
$inserir = mysqli_query ($conexao, "INSERT INTO classificacao_pessoa (codigo, nome, tipo, bloqueio, estado_registro, usuario_cadastro, data_cadastro, hora_cadastro) VALUES (NULL, '$nome_form', '$tipo_form', 'NAO', 'ATIVO', '$usuario_cadastro', '$data_cadastro', '$hora_cadastro')");

// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#0000FF'>Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o cadastrada com sucesso!</div>";
$nome_form = "";
$tipo_form = "";
$bloqueio_w = "";
}

elseif ($botao == "CADASTRAR" and $permissao[73] != "S")
{
// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#FF0000'>Usu&aacute;rio sem autoriza&ccedil;&atilde;o para cadastrar Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o</div>";
$nome_form = "";
$tipo_form = "";
$bloqueio_w = "";
}

else
{}
// ==================================================================================================================


// ====== EDITAR CLASSIFICAÇÃO ======================================================================================
if ($botao == "EDITAR" and $erro == 0 and $permissao[73] == "S")
{
// EDIÇÃO
$editar = mysqli_query ($conexao, "UPDATE classificacao_pessoa SET nome='$nome_form', tipo='$tipo_form', usuario_alteracao='$usuario_cadastro', data_alteracao='$data_cadastro', hora_alteracao='$hora_cadastro' WHERE codigo='$codigo_w'");

// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#0000FF'>Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o editada com sucesso!</div>";
$nome_form = "";
$tipo_form = "";
$bloqueio_w = "";
}

elseif ($botao == "EDITAR" and $permissao[73] != "S")
{
// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#FF0000'>Usu&aacute;rio sem autoriza&ccedil;&atilde;o para editar Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o</div>";
$nome_form = "";
$tipo_form = "";
$bloqueio_w = "";
}

else
{}
// ==================================================================================================================


// ====== ATIVAR / INATIVAR CLASSIFICAÇÃO ===========================================================================
if ($botao == "ATIVAR" and $permissao[73] == "S")
{
// ATIVAR
$ativar = mysqli_query ($conexao, "UPDATE classificacao_pessoa SET estado_registro='ATIVO', usuario_alteracao='$usuario_cadastro', data_alteracao='$data_cadastro', hora_alteracao='$hora_cadastro' WHERE codigo='$codigo_w'");

// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#0000FF'>Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o ativada com sucesso!</div>";
}

elseif ($botao == "INATIVAR" and $permissao[73] == "S")
{
// INATIVAR
$inativar = mysqli_query ($conexao, "UPDATE classificacao_pessoa SET estado_registro='INATIVO', usuario_alteracao='$usuario_cadastro', data_alteracao='$data_cadastro', hora_alteracao='$hora_cadastro' WHERE codigo='$codigo_w'");

// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#0000FF'>Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o inativada com sucesso!</div>";
}

elseif (($botao == "INATIVAR" or $botao == "ATIVAR") and $permissao[73] != "S")
{
// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#FF0000'>Usu&aacute;rio sem autoriza&ccedil;&atilde;o para editar Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o</div>";
}

else
{}
// ==================================================================================================================


// ====== EXCLUIR CLASSIFICAÇÃO =====================================================================================
if ($botao == "EXCLUIR" and $permissao[73] == "S")
{
// EXCLUSAO
$excluir = mysqli_query ($conexao, "UPDATE classificacao_pessoa SET estado_registro='EXCLUIDO', usuario_exclusao='$usuario_cadastro', data_exclusao='$data_cadastro', hora_exclusao='$hora_cadastro' WHERE codigo='$codigo_w'");

// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#0000FF'>Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o exclu&iacute;da com sucesso!</div>";
$nome_form = "";
$tipo_form = "";
$codigo_w = "";
$bloqueio_w = "";
}

elseif ($botao == "EXCLUIR" and $permissao[73] != "S")
{
// MONTA MENSAGEM
$msg = "<div id='oculta' style='color:#FF0000'>Usu&aacute;rio sem autoriza&ccedil;&atilde;o para excluir Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o</div>";
$nome_form = "";
$tipo_form = "";
$codigo_w = "";
$bloqueio_w = "";
}

else
{}
// ==================================================================================================================


// ====== BUSCA CADASTROS ==========================================================================================
$busca_registro = mysqli_query ($conexao, "SELECT * FROM classificacao_pessoa WHERE estado_registro!='EXCLUIDO' ORDER BY nome");
$linha_registro = mysqli_num_rows ($busca_registro);
// ==================================================================================================================


// ================================================================================================================
include ("../../includes/head.php"); 
?>


<!-- ====== TÍTULO DA PÁGINA ====================================================================================== -->
<title>
<?php echo "$titulo"; ?>
</title>


<!-- ====== JAVASCRIPT ============================================================================================ -->
<script type="text/javascript">
<?php include ("../../includes/javascript.php"); ?>

// Função oculta DIV depois de alguns segundos
setTimeout(function() {
   $('#oculta').fadeOut('fast');
}, 4000); // 4 Segundos

</script>
</head>


<!-- ====== INÍCIO ================================================================================================ -->
<body onload="javascript:foco('ok');">


<!-- ====== TOPO ================================================================================================== -->
<div class="topo">
<?php  include ("../../includes/topo.php"); ?>
</div>


<!-- ====== MENU ================================================================================================== -->
<div class="menu">
<?php include ("../../includes/menu_cadastro.php"); ?>
</div>

<div class="submenu">
<?php include ("../../includes/submenu_cadastro_pessoas.php"); ?>
</div>


<!-- ====== CENTRO ================================================================================================= -->
<div class="ct_auto">


<!-- ============================================================================================================= -->
<div class="espacamento_15"></div>
<!-- ============================================================================================================= -->


<!-- ============================================================================================================= -->
<div class="ct_topo_1">
	<div class="ct_titulo_1">
    <?php echo "$titulo"; ?>
    </div>

	<div class="ct_subtitulo_right" style="margin-top:8px">
	<?php 
    if ($linha_registro == 1)
    {echo "<i>$linha_registro Cadastro</i>";}
    elseif ($linha_registro == 0)
    {echo "";}
    else
    {echo "<i>$linha_registro Cadastros</i>";}
    ?>
    </div>
</div>
<!-- ============================================================================================================= -->


<!-- ============================================================================================================= -->
<div class="ct_topo_2">
	<div class="ct_subtitulo_left">
    <?php echo"$msg"; ?>
    </div>

	<div class="ct_subtitulo_right">
	<!-- xxxxxxxxxxxxxxxxx -->
    </div>
</div>
<!-- ============================================================================================================= -->


<div class="pqa" style="height:63px">
<!-- ======================================= FORMULARIO ========================================================== -->


<!-- ======= ESPAÇAMENTO ============================================================================================ -->
<div style="width:50px; height:50px; border:1px solid transparent; margin-top:6px; float:left">
    <form action="<?php echo"$servidor/$diretorio_servidor"; ?>/cadastros/pessoas/classificacao_pessoa.php" method="post" />
    <?php
	if ($botao == "EDICAO")
	{echo "
	<input type='hidden' name='botao' value='EDITAR' />
	<input type='hidden' name='codigo_w' value='$codigo_w' />";}
	
	elseif ($botao == "EXCLUSAO")
	{echo "
	<input type='hidden' name='botao' value='EXCLUIR' />
	<input type='hidden' name='codigo_w' value='$codigo_w' />";}
	
	else
	{echo "<input type='hidden' name='botao' value='CADASTRAR' />";}
	?>
</div>
<!-- ================================================================================================================ -->


<!-- ======= NOME CLASSIFICACAO ===================================================================================== -->
<div style="width:230px; height:50px; border:1px solid transparent; margin-top:6px; float:left">
    <div class="form_rotulo" style="width:228px; height:17px; border:1px solid transparent; float:left">
    Nome da Classifica&ccedil;&atilde;o/Fun&ccedil;&atilde;o:
    </div>
    
    <div style="width:228px; height:25px; float:left; border:1px solid transparent">
    <input type="text" name="nome_form" class="form_input" id="ok" maxlength="30" onBlur="alteraMaiusculo(this)"
    onkeydown="if (getKey(event) == 13) return false;" style="width:200px; text-align:left; padding-left:5px" value="<?php echo"$nome_form"; ?>" />
    </div>
</div>
<!-- ================================================================================================================ -->


<!-- ======= TIPO CLASSIFICACAO ===================================================================================== -->
<div style="width:190px; height:50px; border:1px solid transparent; margin-top:6px; float:left">
    <div class="form_rotulo" style="width:188px; height:17px; border:1px solid transparent; float:left">
    Tipo:
    </div>
    
    <div style="width:188px; height:25px; float:left; border:1px solid transparent">
    <select name="tipo_form" class="form_select" onkeydown="if (getKey(event) == 13) return false;" style="width:160px" />
    <option></option>
	<?php
    if ($tipo_form == "classificacao")
    {echo "<option selected='selected' value='classificacao'>Classifica&ccedil;&atilde;o</option>";}
    else
    {echo "<option value='classificacao'>Classifica&ccedil;&atilde;o</option>";}
    
    if ($tipo_form == "funcao")
    {echo "<option selected='selected' value='funcao'>Fun&ccedil;&atilde;o</option>";}
    else
    {echo "<option value='funcao'>Fun&ccedil;&atilde;o</option>";}
    ?>
    </select>
    </div>
</div>
<!-- ================================================================================================================ -->


<!-- ======= BOTAO ================================================================================================== -->
<div style="width:100px; height:50px; border:1px solid transparent; margin-top:6px; float:left">
    <div class="form_rotulo" style="width:95px; height:17px; border:1px solid transparent; float:left">
    <!-- Botão: -->
    </div>
    
    <div style="width:95px; height:25px; float:left; border:1px solid transparent">
	<?php
	if ($botao == "EDICAO")
	{echo "<button type='submit' class='botao_1'>Salvar</button>";}

	elseif ($botao == "EXCLUSAO")
	{echo "<button type='submit' class='botao_1'>Excluir</button>";}

	else
	{echo "<button type='submit' class='botao_1'>Cadastrar</button>";}
	?>
    </form>
    </div>
</div>
<!-- ================================================================================================================ -->


<!-- ======= BOTAO CANCELAR ========================================================================================= -->
<div style="width:100px; height:50px; border:1px solid transparent; margin-top:6px; float:left">
    <div class="form_rotulo" style="width:95px; height:17px; border:1px solid transparent; float:left">
    <!-- Botão: -->
    </div>
    
    <div style="width:95px; height:25px; float:left; border:1px solid transparent">
	<?php
	if ($botao == "EDICAO")
	{echo "
	<form action='$servidor/$diretorio_servidor/cadastros/pessoas/classificacao_pessoa.php' method='post' />
	<button type='submit' class='botao_1'>Cancelar</button>
	</form>";}

	elseif ($botao == "EXCLUSAO")
	{echo "
	<form action='$servidor/$diretorio_servidor/cadastros/pessoas/classificacao_pessoa.php' method='post' />
	<button type='submit' class='botao_1'>Cancelar</button>
	</form>";}

	else
	{}
	?>
    </div>
</div>
<!-- ================================================================================================================ -->


</div>
<!-- ============================================================================================================= -->



<!-- ============================================================================================================= -->
<div class="espacamento_20"></div>
<!-- ============================================================================================================= -->


<!-- ============================================================================================================= -->
<?php
if ($linha_registro == 0)
{echo "
<div style='height:210px'>
<div class='espacamento_30'></div>";}

else
{echo "
<div class='ct_relatorio'>
<div class='espacamento_10'></div>

<table class='tabela_cabecalho'>
<tr>
<td width='300px'>Nome</td>
<td width='200px'>Tipo</td>
<td width='150px'>Status</td>
<td width='60px'>Editar</td>
<td width='60px'>Inativar</td>
<td width='60px'>Excluir</td>
</tr>
</table>";}


echo "<table class='tabela_geral' style='font-size:12px'>";


// ====== FUNÇÃO FOR ===================================================================================
for ($x=1 ; $x<=$linha_registro ; $x++)
{
$aux_registro = mysqli_fetch_row($busca_registro);

// ====== DADOS DO CADASTRO ============================================================================
$codigo_w = $aux_registro[0];
$nome_w = $aux_registro[1];
$tipo_w = $aux_registro[2];
$bloqueio_w = $aux_registro[3];
$estado_registro_w = $aux_registro[5];

if ($tipo_w == "classificacao")
{$tipo_print = "CLASSIFICA&Ccedil;&Atilde;O";}
elseif ($tipo_w == "funcao")
{$tipo_print = "FUN&Ccedil;&Atilde;O";}
else
{$tipo_print = "";}

$usuario_cadastro_w = $aux_registro[6];
if ($usuario_cadastro_w == "")
{$dados_cadastro_w = "";}
else
{
$data_cadastro_w = date('d/m/Y', strtotime($aux_registro[7]));
$hora_cadastro_w = $aux_registro[8];
$dados_cadastro_w = "Cadastrado por: $usuario_cadastro_w $data_cadastro_w $hora_cadastro_w";
}

$usuario_alteracao_w = $aux_registro[9];
if ($usuario_alteracao_w == "")
{$dados_alteracao_w = "";}
else
{
$data_alteracao_w = date('d/m/Y', strtotime($aux_registro[10]));
$hora_alteracao_w = $aux_registro[11];
$dados_alteracao_w = "Editado por: $usuario_alteracao_w $data_alteracao_w $hora_alteracao_w";
}
// ======================================================================================================


// ====== BLOQUEIO PARA EDITAR ========================================================================
if ($estado_registro_w == "ATIVO" and $bloqueio_w != "SIM")
{$permite_editar = "SIM";}
else
{$permite_editar = "NAO";}
// ========================================================================================================


// ====== BLOQUEIO PARA ATIVAR ========================================================================
$permite_ativar = "SIM";
/*
if ($permissao[73] == "S")
{$permite_ativar = "SIM";}
else
{$permite_ativar = "NAO";}
*/
// ========================================================================================================


// ====== BLOQUEIO PARA EXCLUIR ========================================================================
if ($estado_registro_w == "ATIVO" and $bloqueio_w != "SIM")
{$permite_excluir = "SIM";}
else
{$permite_excluir = "NAO";}
// ========================================================================================================


// ====== RELATORIO ========================================================================================
if ($estado_registro_w == "ATIVO")
{echo "<tr class='tabela_1' title=' C&oacute;digo: $codigo_w &#13; $dados_cadastro_w &#13; $dados_alteracao_w'>";}
else
{echo "<tr class='tabela_4' title=' C&oacute;digo: $codigo_w &#13; $dados_cadastro_w &#13; $dados_alteracao_w'>";}

echo "
<td width='300px' align='left'><div style='height:14px; margin-left:7px; overflow:hidden'>$nome_w</div></td>
<td width='200px' align='center'>$tipo_print</td>
<td width='150px' align='center'>$estado_registro_w</td>";

// ====== BOTAO EDITAR ===================================================================================================
	if ($permite_editar == "SIM")
	{	
		echo "
		<td width='60px' align='center'>
		<form action='$servidor/$diretorio_servidor/cadastros/pessoas/classificacao_pessoa.php' method='post'>
		<input type='hidden' name='pagina_mae' value='$pagina'>
		<input type='hidden' name='botao' value='EDICAO'>
		<input type='hidden' name='codigo_w' value='$codigo_w'>
		<input type='hidden' name='nome_form' value='$nome_w'>
		<input type='hidden' name='tipo_form' value='$tipo_w'>
		<input type='hidden' name='bloqueio_w' value='$bloqueio_w'>
		<input type='image' src='$servidor/$diretorio_servidor/imagens/botoes/editar.png' height='20px' border='0' />
		</form>	
		</td>";
	}

	else
	{
		echo "
		<td width='60px' align='center'></td>";
	}
// =================================================================================================================

// ====== BOTAO ATIVAR / INATIVAR ==================================================================================
	if ($permite_ativar == "SIM" and $estado_registro_w == "INATIVO")
	{	
		echo "
		<td width='60px' align='center'>
		<form action='$servidor/$diretorio_servidor/cadastros/pessoas/classificacao_pessoa.php' method='post'>
		<input type='hidden' name='pagina_mae' value='$pagina'>
		<input type='hidden' name='botao' value='ATIVAR'>
		<input type='hidden' name='codigo_w' value='$codigo_w'>
		<input type='image' src='$servidor/$diretorio_servidor/imagens/botoes/inativo.png' height='20px' border='0' />
		</form>	
		</td>";
	}

	elseif ($permite_ativar == "SIM" and $estado_registro_w == "ATIVO")
	{	
		echo "
		<td width='60px' align='center'>
		<form action='$servidor/$diretorio_servidor/cadastros/pessoas/classificacao_pessoa.php' method='post'>
		<input type='hidden' name='pagina_mae' value='$pagina'>
		<input type='hidden' name='botao' value='INATIVAR'>
		<input type='hidden' name='codigo_w' value='$codigo_w'>
		<input type='image' src='$servidor/$diretorio_servidor/imagens/botoes/ativo.png' height='20px' border='0' />
		</form>	
		</td>";
	}

	else
	{
		echo "
		<td width='60px' align='center'></td>";
	}
// =================================================================================================================

// ====== BOTAO EXCLUIR ===================================================================================================
	if ($permite_excluir == "SIM")
	{	
		echo "
		<td width='60px' align='center'>
		<form action='$servidor/$diretorio_servidor/cadastros/pessoas/classificacao_pessoa.php' method='post'>
		<input type='hidden' name='pagina_mae' value='$pagina'>
		<input type='hidden' name='botao' value='EXCLUSAO'>
		<input type='hidden' name='codigo_w' value='$codigo_w'>
		<input type='hidden' name='nome_form' value='$nome_w'>
		<input type='hidden' name='tipo_form' value='$tipo_w'>
		<input type='hidden' name='bloqueio_w' value='$bloqueio_w'>
		<input type='image' src='$servidor/$diretorio_servidor/imagens/botoes/excluir.png' height='20px' border='0' />
		</form>	
		</td>";
	}

	else
	{
		echo "
		<td width='60px' align='center'></td>";
	}
// =================================================================================================================


}

echo "</table>";
// =================================================================================================================



// =================================================================================================================
if ($linha_registro == 0)
{echo "
<div class='espacamento_30'></div>
<div style='height:30px; width:880px; border:0px solid #000; color:#F00; font-size:14px; margin:auto; text-align:center'>
<i>>Nenhuma classifica&ccedil;&atilde;o cadastrada.</i></div>";}
// =================================================================================================================
?>



<!-- ============================================================================================================= -->
<div class="espacamento_30"></div>
<!-- ============================================================================================================= -->



</div>
<!-- ====== FIM DIV CT_RELATORIO =============================================================================== -->



<!-- ============================================================================================================= -->
<div class="espacamento_40"></div>
<!-- ============================================================================================================= -->


<!-- ============================================================================================================= -->
<div class="contador">
	<div class="ct_subtitulo_left" style="width:1000px; float:left; margin-left:25px; text-align:left; font-size:12px">
	<!-- ======== Observações ============= -->
	</div>
</div>

<div class="contador">
	<div class="ct_subtitulo_left" style="width:1000px; float:left; margin-left:25px; text-align:left; font-size:12px">
	<!-- ======== Observações ============= -->
	</div>
</div>

<div class="contador">
	<div class="ct_subtitulo_left" style="width:1000px; float:left; margin-left:25px; text-align:left; font-size:12px">
	<!-- ======== Observações ============= -->
	</div>
</div>
<!-- ============================================================================================================= -->


<!-- ============================================================================================================= -->
<div class="espacamento_10"></div>
<!-- ============================================================================================================= -->



</div>
<!-- ====== FIM DIV CT ========================================================================================= -->



<!-- ====== RODAPÉ =============================================================================================== -->
<div class="rdp_1">
<?php include ("../../includes/rodape.php"); ?>
</div>


<!-- ====== FIM ================================================================================================== -->
<?php include ("../../includes/desconecta_bd.php"); ?>
</body>
</html>