﻿<?php
header ("Location: https://suif.grancafe.com.br/sis/index.php");
exit;
?>